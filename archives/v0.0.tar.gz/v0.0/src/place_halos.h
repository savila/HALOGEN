int place_halos(long , double *, long, long , float *, float *, float *, float , float , double *, double *,long,float *, float *, float *);
