int place_halos(long , double *, long, long , float *, float *, float *, float , float , float, long,double *, double *,long,float *, float *, float *);
