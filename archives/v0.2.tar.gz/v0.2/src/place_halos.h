int place_halos(long , float *, long, long , float *, float *, float *, float , float , long,float,double *, double *,long,float *, float *, float *, float *);
