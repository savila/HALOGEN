float compute_ji_2(char *, char *, float , float );
