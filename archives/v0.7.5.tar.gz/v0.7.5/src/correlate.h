int correlate(long, float, float *, float *, float *, double *, double *, unsigned long long *, int, double,int);
