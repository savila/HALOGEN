int read_snapshot(char *, int, float, float, int, int, int, int,int,float **, float **, float **, float **,float**,float**,long *, float *, float *, float *, long ***,long **,float **);
int read_snapshot_serial(char *, int , float , float , int , int, int , int , int , float **, float **, float **, float **, float **, float **,long *, float *, float *, float*,long ***,long **,float **);
